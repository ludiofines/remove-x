frame = document.getElementById('html5video');
if (frame !== null)
{
	frame.style.display = '';
	console.log('removed x');
}
console.log('remove x');
console.log(frame);
